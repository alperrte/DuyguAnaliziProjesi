"""Türkçe metinlerin İngilizce çevirisi."""
