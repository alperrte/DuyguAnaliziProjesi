"""Karşılaştırmalı duygu analizi."""
