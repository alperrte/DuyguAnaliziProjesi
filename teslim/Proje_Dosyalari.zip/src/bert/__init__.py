"""BERT tabanlı duygu analizi."""
