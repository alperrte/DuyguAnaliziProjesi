"""VADER ile duygu analizi."""
