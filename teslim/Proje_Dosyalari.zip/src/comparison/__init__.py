"""Model tahminlerinin karşılaştırılması."""
